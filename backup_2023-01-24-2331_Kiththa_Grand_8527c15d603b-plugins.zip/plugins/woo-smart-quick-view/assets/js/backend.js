'use strict';

(function($) {
  $(function() {
    $('.woosq-summary').sortable({
      handle: '.label',
    });
  });
})(jQuery);